# Olrait - Sitio Web

Sitio listo para desplegar en Vercel. Dominio propio y estilo rústico/mediterráneo. 
Dirección: Plaza Pedagogo Pestalozzi 1, Valencia, 46006, España
Teléfono: +34 960 54 36 60

## Pasos rápidos
1. Instala dependencias: `npm install`
2. Ejecuta local: `npm run dev`
3. Sube a GitHub y conecta a Vercel

