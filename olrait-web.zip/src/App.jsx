import React from 'react'
import OlraitLanding from './components/OlraitLandingAdvanced'

export default function App(){
  return <OlraitLanding />
}
