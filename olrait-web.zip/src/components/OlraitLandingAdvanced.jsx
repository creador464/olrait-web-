import React, { useState } from 'react'
import { Clock, MapPin, Phone, Mail } from 'lucide-react'

const MENU = {
  es: [
    { category: 'Entrantes', items: [{name:'Esgarrat de la casa', price:'8 €', desc:'Bacalao, pimiento asado'}, {name:'Croquetas caseras (6)', price:'7 €', desc:'Pernil / bolets'}]},
    { category: 'Arroces (mín. 2 pax)', items: [{name:'Paella de marisco', price:'16 €/pax', desc:'Marisco fresco y caldo reducid'}, {name:'Arroz a banda', price:'14 €/pax', desc:'Con allioli suave'}]},
    { category: 'Postres', items: [{name:'Tarta de queso casera', price:'5 €', desc:'Coulis de fruta'}, {name:'Helado artesano', price:'4 €', desc:'Sabores rotativos'}]}
  ],
  en: [
    { category: 'Starters', items: [{name:'House Esgarrat', price:'8 €', desc:'Salted cod & roasted pepper'}]},
    { category: 'Rices (min. 2 pax)', items: [{name:'Seafood paella', price:'16 €/pax', desc:'Fresh seafood & rich broth'}]},
  ],
  va: [
    { category: 'Entrants', items: [{name:'Esgarrat de la casa', price:'8 €', desc:'Bacallà i pebrot rostit'}]}
  ]
}

export default function OlraitLandingAdvanced(){
  const [lang, setLang] = useState('es')
  const t = {
    es: { reservar:'Reservar', verCarta:'Ver carta', contacto:'Contacto', horario:'Horario', ubicacion:'Ubicación' },
    en: { reservar:'Book', verCarta:'See menu', contacto:'Contact', horario:'Opening hours', ubicacion:'Location' },
    va: { reservar:'Reservar', verCarta:'Veure carta', contacto:'Contacte', horario:'Horari', ubicacion:'Ubicació' }
  }[lang]

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-amber-50 to-white text-gray-900">
      <header className="container mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full header-logo flex items-center justify-center text-white font-bold">O</div>
          <div>
            <h1 className="text-xl font-extrabold">Olrait</h1>
            <p className="text-sm text-gray-600">Cocina valenciana · Plaza Pedagogo Pestalozzi 1</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <select value={lang} onChange={e=>setLang(e.target.value)} className="p-2 border rounded">
            <option value="es">ES</option>
            <option value="en">EN</option>
            <option value="va">VA</option>
          </select>
          <a href="#reservas" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg">{t.reservar}</a>
        </div>
      </header>

      <main className="container mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-4xl font-extrabold leading-tight">Olrait — Sabores del Mediterráneo</h2>
          <p className="mt-4 text-gray-700 max-w-xl">Cocina de mercado con alma mediterránea. Arroces tradicionales y platos para compartir en un espacio rústico y acogedor.</p>
          <div className="mt-6 flex gap-3">
            <a href="#reservas" className="px-5 py-3 rounded-lg bg-primary text-white font-semibold">{t.reservar}</a>
            <a href="#menu" className="px-5 py-3 rounded-lg border border-primary text-primary">{t.verCarta}</a>
          </div>
          <dl className="mt-6 grid grid-cols-2 gap-4 text-sm text-gray-600 max-w-lg">
            <div className="flex gap-3 items-center"><Clock size={18} /><div><dt className="font-semibold">{t.horario}</dt><dd>12:00–16:00 · 20:00–23:30</dd></div></div>
            <div className="flex gap-3 items-center"><MapPin size={18} /><div><dt className="font-semibold">{t.ubicacion}</dt><dd>Plaza Pedagogo Pestalozzi 1, Valencia</dd></div></div>
          </dl>
        </div>
        <div className="rounded-2xl overflow-hidden shadow-lg">
          <img src="/assets/olrait-foto1.png" alt="Sala Olrait" className="w-full h-80 object-cover" />
        </div>
      </main>

      <section id="menu" className="container mx-auto px-6 py-12">
        <h3 className="text-2xl font-bold">La carta</h3>
        <div className="mt-6 grid gap-8 md:grid-cols-3">
          {MENU[lang].map(sec => (
            <article key={sec.category} className="bg-white p-6 rounded-2xl shadow">
              <h4 className="font-semibold text-lg">{sec.category}</h4>
              <ul className="mt-4 space-y-3">
                {sec.items.map(it => (
                  <li key={it.name} className="flex justify-between items-start">
                    <div><p className="font-medium">{it.name}</p><p className="text-xs text-gray-500">{it.desc}</p></div>
                    <div className="text-sm font-semibold">{it.price}</div>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className="mt-6 text-sm text-gray-600">Descarga la carta completa: <a href="/assets/Olrait_Pack_Comercial.pdf" className="text-primary underline">PDF</a></div>
      </section>

      <section id="reservas" className="container mx-auto px-6 py-12 bg-amber-50 rounded-2xl">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-2xl font-bold">Reservas</h3>
            <form id="reserva-form" className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-3" onSubmit={async e=>{e.preventDefault(); const f=new FormData(e.target); const body=Object.fromEntries(f); await fetch('/api/reservas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); alert('Reserva enviada — os contactaremos pronto.'); e.target.reset(); }}>
              <input name="name" placeholder="Nombre" className="p-3 rounded border" required />
              <input name="phone" placeholder="Teléfono o WhatsApp" className="p-3 rounded border" required defaultValue="+34 960 54 36 60" />
              <input name="date" type="date" className="p-3 rounded border" required />
              <select name="guests" className="p-3 rounded border"><option>2 personas</option><option>3 personas</option><option>4 personas</option><option>+5 personas</option></select>
              <textarea name="notes" placeholder="Comentarios / alérgenos" className="p-3 rounded border md:col-span-2" />
              <button type="submit" className="md:col-span-2 py-3 rounded bg-primary text-white font-semibold">Enviar reserva</button>
            </form>
          </div>
          <div>
            <h4 className="font-semibold">Contacto</h4>
            <div className="mt-4 text-sm text-gray-700"><div className="flex items-center gap-2"><Phone size={16} /> <span>+34 960 54 36 60</span></div><div className="flex items-center gap-2 mt-1"><Mail size={16} /> <span>hola@olrait.es</span></div></div>
          </div>
        </div>
      </section>

      <footer className="container mx-auto px-6 py-12 border-t">
        <div className="grid md:grid-cols-3 gap-6 items-start">
          <div><h4 className="font-bold text-lg">Olrait</h4><p className="text-sm text-gray-600">Cocina mediterránea y arroces tradicionales.</p></div>
          <div className="col-span-2"><h5 className="font-semibold">Localización</h5><div className="mt-3 rounded overflow-hidden shadow-sm"><img src="/assets/olrait-foto2.png" alt="Mapa" className="w-full h-48 object-cover" /></div><div className="mt-3 text-sm text-gray-600">Plaza Pedagogo Pestalozzi 1, Valencia · <a href="#" className="text-primary underline">Cómo llegar</a></div></div>
        </div>
        <div className="mt-8 text-xs text-gray-500">© {new Date().getFullYear()} Olrait — Diseño y web por [Tu nombre]</div>
      </footer>
    </div>
  )
}
