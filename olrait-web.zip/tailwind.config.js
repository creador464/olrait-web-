/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#B9772A', // warm mediterranean amber
        wood: '#8B5E3C'
      }
    }
  },
  plugins: [],
}
